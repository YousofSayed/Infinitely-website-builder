
export const open_symbols_manager = "open:symbols-manager";
export const close_current_modal = 'close:current:modal';
export const select_page = 'select:page';
export const open_rest_models_modal = `open:models:modal`;
export const open_dynamic_templates_modal = `open:dynamic-templates-manager:modal`;
export const open_library_installer_modal = `open:library-installer:modal`;
export const open_pages_manager_modal = `open:pages-manager`;
export const open_files_manager_modal = `open:files-manager`;
export const open_custom_font_installer_modal = `open:custom-font-installer`
export const open_settings_modal = `open:settings:modal`;
export const open_page_helmet_modal = `open:page-helmet:modal`;
export const open_code_manager_modal = `open:code-manager:modal`;
export const open_symbols_and_templates_manager_modal = `open:symbols-and-templates-manager:modal`;
export const open_file_editor_modal = `open:file-editor:modal`;
export const open_symbol_code_editor_modal = `open:symbol-code-editor:modal`;
