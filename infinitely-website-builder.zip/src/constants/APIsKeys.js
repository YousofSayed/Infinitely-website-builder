
export const google_fonts_api_key = 'AIzaSyCqCk8qWvwqrJbOzQtoRL2sjBaXeW_fm7U';
