
export const db_name = 'Infinitely';
