import { projectSettingsState } from "@/helpers/atoms";
import { getProjectSettings } from "@/helpers/functions";
import { useRecoilState, useRecoilValue, useSetRecoilState } from "recoil";

/**
 * 
 * @returns {[import('@/helpers/types').ProjectSetting , React.Dispatch<React.SetStateAction<import('@/helpers/types').ProjectSetting>>]}
 */
export const useProjectSettings = () => {
  const projectSettingsFromLocal = getProjectSettings();
  const [projectSettings , setProjectSettingsRs] = useRecoilState(projectSettingsState);
  // const setProjectSettingsRs = useSetRecoilState(projectSettingsState);
  console.log('projectSettings : ' , projectSettings);
  
  /**
   *
   * @param {import('@/helpers/types').ProjectSetting} newSettings
   */
  const setProjectSetting = (newSettings) => {
    projectSettingsFromLocal.set(newSettings);
    setProjectSettingsRs((old) => ({ ...old, ...newSettings }));
    window.dispatchEvent(new CustomEvent('local-storage',{detail:{ ...projectSettings, ...newSettings }}))
  };
  return [projectSettings, setProjectSetting];
};
