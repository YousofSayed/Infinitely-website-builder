import { ToastMsgInfo } from "@/components/Editor/Protos/ToastMsgInfo";
import {
  doActionAndPreventSaving,
  getInfinitelySymbolInfo,
  initToolbar,
  renderToolbar,
} from "@/helpers/functions";
import React from "react";
import { toast } from "react-toastify";

/**
 *
 * @param {import('grapesjs').Component} model
 */
const isSvgComponent = (model) => {
  if (model.tagName.toLowerCase() == "svg") return true;
  if (model.parents().some((parent) => parent.tagName.toLowerCase() == "svg"))
    return true;

  return false;
};

/**
 *
 * @param {import('grapesjs').Editor} editor
 * @returns
 */
export const addNewTools = (editor) => {
  /**
   * @type {Interact.Interactable}
   */
  let interacter;

  /**
   *
   * @param {boolean} value
   * @param {import('grapesjs').Component} cmp
   */
  const disableDragAndDrop = (value = false, cmp) => {
    const props = cmp.props();
    cmp.set({
      ...props,
      draggable: value,
      droppable: value || false,
    });
    // editor.select()
    cmp.forEachChild((child) => disableDragAndDrop(value, child));
  };
  // editor.on("component:update", (update) => {
  //   console.log("update", update, editor.getDirtyCount());
  // });

  editor.on(
    "component:create",
    /**
     *
     * @param {import('grapesjs').Component} model
     */
    (model) => {
      // console.log("component create : ", model);
      if (model.get("type") == "wrapper") return;
      if (isSvgComponent(model)) {
        model.removeClass(["drop"]);
        model.set({
          droppable: false,
        });
        return;
      }
      const props = model.props();
      if (props.droppable && model.components().length == 0) {
        console.log("component create droppp: ", model);
        doActionAndPreventSaving(
          editor,
          () => {
            model.addClass(["drop"]);
          },
          { decreaseSteps: true }
        );
      }
    }
  );

  editor.on(
    "component:add",
    /**
     *
     * @param {import('grapesjs').Component} model
     */
    (model) => {
      if (!model) return;
      const parent = model.parent();
      if (!parent) return;
      if (parent.get("type") == "wrapper") return;
      if (isSvgComponent(model)) {
        model.removeClass(["drop"]);
        model.set({
          droppable: false,
        });
        return;
      }
      const modelClasses = [...parent.getClasses()];

      if (modelClasses.includes("drop")) {
        console.log("mod 2", modelClasses);
        doActionAndPreventSaving(
          editor,
          (ed) => {
            parent.removeClass(["drop"]);
          },
          { decreaseSteps: true }
        );
      }

      // console.log(model.parent(), editor.getDirtyCount(), "from adder after");
    }
  );

  editor.on(
    "component:update:components",
    /**
     *
     * @param {import('grapesjs').Component} model
     */
    (model) => {
      if (!model) {
        console.warn("no model!!");
        return;
      }
      if (model.get("type") == "wrapper") return;
      if (isSvgComponent(model)) {
        model.removeClass(["drop"]);
        model.set({
          droppable: false,
        });
        return;
      }
      const props = model.props();
      if (props.droppable && !model.components().length) {
        model.addClass(["drop"]);
      }
    }
  );

  editor.on(
    "component:remove",
    /**
     *
     * @param {import('grapesjs').Component} model
     */
    (model) => {
      // console.log(model.parent(), editor.getDirtyCount(), "from remover out");
      if (!model) return;
      const parent = model.parent();
      if (!parent) return;
      if (parent.get("type") == "wrapper") return;
      if (isSvgComponent(model)) {
        model.removeClass(["drop"]);
        model.set({
          droppable: false,
        });
        return;
      }
      // const modelClasses = [...parent.getClasses()];
      // console.log(
      //   "mod",
      //   modelClasses,
      //   parent.components().length > 1,
      //   modelClasses.includes("drop")
      // );

      if (parent.components().length === 0 && parent.props().droppable) {
        // console.log(
        //   model.parent(),
        //   editor.getDirtyCount(),
        //   "from remover inside"
        // );
        // console.log("mod 2", modelClasses);
        doActionAndPreventSaving(
          editor,
          (ed) => {
            parent.addClass(["drop"]);
          }
          // { decreaseSteps: true }
        );
      }

      // console.log(model.parent(), editor.getDirtyCount(), "from remover after");
    }
  );

  let scrollTimeout,
    isToggleActive = false,
    isScrollValue = false;
  // editor.on(
  //   "canvas:frame:load",
  //   /**
  //    *
  //    * @param {{window : Window , el : HTMLIFrameElement}} param0
  //    */
  //   ({ window, el }) => {
  //     const frameEl = el; // <iframe> element
  //     const frameWindow = window; // iframe window
  //     const frameDocument = frameWindow.document; // iframe document
  //     const frameBody = window.document.body; // body inside iframe

  //     // console.log("Canvas Frame Loaded:", {
  //     //   frameWindow,
  //     //   frameDocument,
  //     //   frameBody,
  //     // });

  //     // Make the canvas always full height of the iframe
  //     frameBody.style.minHeight = frameWindow.outerHeight + "px"; // Full screen height
  //     frameBody.style.height = "auto";
  //     frameBody.style.overflow = "auto"; // Allow scroll only if content is taller
  //     frameDocument.documentElement.style.overflow = "auto";

  //     let scrollTimeout;

  //     // Listen for scroll inside the canvas
  //     frameWindow.addEventListener(
  //       "scroll",
  //       () => {
  //         editor.trigger("canvas:frame:scroll", { isScroll: true });

  //         clearTimeout(scrollTimeout);
  //         scrollTimeout = setTimeout(() => {
  //           editor.trigger("canvas:frame:scroll:stop", { isScroll: false });
  //         }, 150); // Fires after scrolling stops
  //       },
  //       { passive: true }
  //     );
  //   }
  // );

  const offsetConfig = editor.config.showOffsets;

  // editor.on("canvas:frame:scroll", ({ isScroll }) => {
  //   // console.log("is scrollll : ", isScroll , window);
  //   isScrollValue = isScroll;
  //   scrollTimeout && clearTimeout(scrollTimeout);
  //   editor
  //     .getWrapper()
  //     .find(`*`)
  //     .forEach((child) => {
  //       child.addClass("preventWhenScroll");
  //       editor.clearDirtyCount();
  //     });
  //   // if (!editor.Commands.isActive("preview")) {
  //   //   isToggleActive = false;
  //   //   editor.runCommand("preview");
  //   // }
  //   // editor.Canvas.getBody().classList.add("preventWhenScroll");
  //   // const hlt = document.querySelector(`.gjs-highlighter`);
  //   // hlt.style.display = "none";
  //   // editor.getConfig().showOffsets = false;
  //   // console.log("scrolling");
  //   // alert(`a7a`);
  // });

  // editor.on("canvas:frame:scroll:stop", ({ isScroll }) => {
  //   // console.log("is scrollll stop: ", isScroll);
  //   scrollTimeout && clearTimeout(scrollTimeout);
  //   scrollTimeout = setTimeout(() => {
  //     editor
  //       .getWrapper()
  //       .find(`*`)
  //       .forEach((child) => {
  //         child.removeClass("preventWhenScroll");
  //         editor.clearDirtyCount();
  //       });
  //   }, 200);
  //   // isScrollValue = isScroll;
  //   // editor.Canvas.getBody().classList.remove("preventWhenScroll");
  //   // const hlt = document.querySelector('.gjs-highlighter');
  //   // hlt.style.display = "block";
  //   // editor.getConfig().showOffsets = offsetConfig;
  //   // console.log("stop scrolling");
  // });

  editor.on(
    "component:hovered",
    /**
     *
     * @param { import('grapesjs').Component } component
     */
    (component) => {
      if (!component) return;
      // if (isScrollValue) {
      //   return
      // };
      // console.log('hoveriiiiiing')
      try {
        // const trg = component && component.getEl();
        const highlighter = document.querySelector(
          `.gjs-cv-canvas .gjs-highlighter`
        );
        const symbolInfo = getInfinitelySymbolInfo(component);
        /**
         * @type {HTMLElement | undefined}
         */
        const badgeEl = editor.Canvas.getBadgeEl();

        if (badgeEl && highlighter && component && symbolInfo.isSymbol) {
          highlighter.classList.add("symbol-highlight");
          badgeEl.classList.add("badge-symbol-highlight");
        } else {
          badgeEl.classList.remove("badge-symbol-highlight");
          highlighter.classList.remove("symbol-highlight");
        }

        const toolbarEl = editor.Canvas.getToolbarEl();
        const top = toolbarEl.style.top;
        const newTopValue = `${toolbarEl.style.top + (top < 0 ? -5 : 5)}px`;
        toolbarEl.style.top = newTopValue;
      } catch (error) {
        throw new Error(error);
      }
    }
  );

  
  editor.on("component:selected", (cmp) => {
    const sle = editor.getSelected();
    const sles = editor.getSelectedAll();
    const symbolInfo = getInfinitelySymbolInfo(sle);

    if (sles.length > 1 && symbolInfo.isSymbol) {
      editor.selectRemove(sle);
      toast.warn(
        <ToastMsgInfo msg={`Symbols not allowd in multi selections`} />
      );
    }

    // editor.config.multipleSelection
    sle.get("type") == "svg" && sle.set({ resizable: true });
    const sleProps = sle.props();
    interacter && interacter.unset();
    console.log("done render");

    if (sle.is("wrapper")) {
      console.log("i am wrapper");
      return;
    }
    initToolbar(editor, sle);
    // console.log("resizable sle :", sle.get("resizable"), sle.get("resizable"));
    // console.log("props sle :", sleProps);
    editor.Canvas.getResizerEl() && editor.Canvas.getResizerEl().remove();
    // const isParentFlexOrGrid = () => {
    //   const el = sle.parent().getEl();
    //   const cmStyles = window.getComputedStyle(el);
    //   const displayVal = cmStyles.display;
    //   return {
    //     isFlex: displayVal == "flex",
    //     isGrid: displayVal == "grid",
    //   };
    // };
   
  });

  // editor.onReady(()=>{
  //   // editor.select(editor.getWrapper());
  //   const toolbarEl = editor.Canvas.getToolbarEl();
  //   toolbarEl.innerHTML='';
  //   renderToolbar(editor);
  //   console.log('inito');
    
  //   setTimeout(() => {
  //   },10)
  // })

  
};
