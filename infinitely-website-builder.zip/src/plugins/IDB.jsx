import { ToastMsgInfo } from "@/components/Editor/Protos/ToastMsgInfo";
import { InfinitelyEvents } from "@/constants/infinitelyEvents";
import {
  current_dynamic_template_id,
  current_page_id,
  current_project_id,
  current_symbol_id,
  current_symbol_rule,
  current_template_id,
  DEV_SCRIPT_DEFINITIONS,
  DEV_STYLE_DEFINITIONS,
  inf_symbol_Id_attribute,
  mainScriptsForEditor,
  SCRIPT_DEFINITIONS,
  STYLE_DEFINITIONS,
} from "@/constants/shared";
import { defineRoot, getPageURLException } from "@/helpers/bridge";
import { changePageName } from "@/helpers/customEvents";
import { db } from "@/helpers/db";
import {
  getComponentRules,
  getInfinitelySymbolInfo,
  getProjectData,
  getProjectSettings,
  initSymbolTimout,
  reloadEditor,
  screenshotTimout,
  workerCallbackMaker,
} from "@/helpers/functions";
import { infinitelyWorker } from "@/helpers/infinitelyWorker";
import { opfs } from "@/helpers/initOpfs";
import { initDBAssetsSw } from "@/serviceWorkers/initDBAssets-sw";
import { updateThumbnailTimeout } from "@/plugins/updateProjectThumbnail";
import { minify } from "csso";
import { isBoolean, isFunction, isPlainObject } from "lodash";
import { toast } from "react-toastify";

//

//

//

let loadFooterScriptsCallback, loadHeadScriptsCallback, loadMainScriptsCallback;
let storeTimeout;
let pageBuilderTimeout;
let loadTimeout, appenderTimeout;
let currentPageName = localStorage.getItem(current_page_id);

/**
 *
 * @param {import('grapesjs').Editor} editor
 * @param {import('@/helpers/types').Project} projectData
 */
const attrsCallback = (editor, projectData) => {
  const { projectSettings } = getProjectSettings();
  editor.Storage.setAutosave(false);

  editor.getWrapper().setClass("");
  /**
   * @type {HTMLBodyElement}
   */
  // const body = ev.window.document.body;
  const currentPageId = localStorage.getItem(current_page_id);
  const attributesAsEntries = Object.entries(
    projectData.pages[`${currentPageId}`].bodyAttributes || {},
  );

  const vAttributesFilterd = attributesAsEntries.filter(
    ([key, value]) => key.startsWith("v-") && value,
  );

  const otherAttributes = attributesAsEntries.filter(
    ([key, value]) => !key.startsWith("v-"),
  );

  // editor.getWrapper().setClass("");
  const attributes = Object.fromEntries(
    vAttributesFilterd.concat(otherAttributes),
  );
  delete attributes["id"];
  if (projectSettings.stop_all_animation_on_page) {
    attributes["class"] = `${
      attributes["class"] || ""
    } inf-stop-all-animations`;
  } else {
    attributes["class"] =
      attributes["class"]?.replace("inf-stop-all-animations", "") || "";
  }
  const classes = attributes?.class || ""; //|| [...editor.getWrapper().getClasses()].join(" ");
  console.log("classes equal : ", classes);

  editor
    .getWrapper()
    .removeAttributes(Object.keys(attributes), { avoidStore: true });

  editor.getWrapper().setAttributes(attributes, {
    avoidStore: true,
    // silent: true,
  });

  editor.clearDirtyCount();

  setTimeout(() => {
    editor.clearDirtyCount();
    editor.Storage.setAutosave(projectSettings.enable_auto_save);
    editor.UndoManager.start();
    editor.trigger(InfinitelyEvents.storage.loadEnd);
    editor.infLoading = false;
  }, 0);
  // editor.on("update", updateDirty);

  clearTimeout(storeTimeout);
  // editor.off("canvas:frame:load:body", callback);
};

async function getAllSymbolsStyles() {
  const projectData = await getProjectData();
  const currentPageId = localStorage.getItem(current_page_id); //it will return void so that will make it take second choics : "index"

  // const currentPage = projectData.pages[`${currentPageId}`];
  const allSymbolsStyle = await (
    await Promise.all(
      Object.values(projectData.blocks)
        // .filter((block) => block.type && block.type != "symbol")
        // .concat(Object.values(projectData.symbols))
        .filter((block) => block.pathes.style)
        .map(
          async (symbol) =>
            await (await opfs.getFile(defineRoot(symbol.pathes.style))).text(),
        ),
    )
  ).join("\n");

  return minify(allSymbolsStyle).css;
}

/**
 *
 * @param {import('grapesjs').Editor} editor
 * @returns
 */
export const loadElements = async (
  editor,
  { justSendToWorker = false, onSend = (response = [], styles) => {} },
) => {
  editor.Components.clear({});
  editor.DomComponents.clear({});
  editor.Css.clear({});
  editor.CssComposer.clear({});
  editor.setStyle("");
  editor.setComponents("");
  // editor.Canvas.canvas.clear({});
  // editor.Canvas.canvas.destroy();
  // editor.Canvas.canvas.init();

  !editor.loadTimes && (editor.loadTimes = 0);
  editor.loadTimes++;
  editor.trigger(InfinitelyEvents.storage.loadStart);
  const projectID = +localStorage.getItem(current_project_id);
  const projectData = await db.projects.get(projectID);
  const projectSettings = getProjectSettings().projectSettings;

  console.time("loading");
  const storageManager = editor.StorageManager;
  const originalAutosave = storageManager.getConfig().autosave;
  storageManager.setAutosave(false);
  let cssCode = "";

  const loadCurrentStyle = async () => {};

  const loadCurrentPage = async () => {
    if (!localStorage.getItem(current_page_id)) {
      localStorage.setItem(current_page_id, "index");
    }
    currentPageName = localStorage.getItem(current_page_id);
    const currentPageId = currentPageName; //it will return void so that will make it take second choics : "index"
    const currentPage = projectData.pages[`${currentPageId}`];
    let cssStyles = await (
      await opfs.getFile(defineRoot(`css/${currentPageId}.css`))
    ).text();
    let allSymbolsStyle = await getAllSymbolsStyles();

    cssCode = minify(
      `
      ${cssStyles}
      ${allSymbolsStyle}
        `,
      { restructure: false },
    ).css;
    // editor.setStyle(cssCode);
    // console.log('style : ',editor.getCss());

    allSymbolsStyle = null; //For garpage collection
    cssStyles = null;

    const getElements = async () => {
      let elements = await new Promise((res, rej) => {
        workerCallbackMaker(
          infinitelyWorker,
          "parseHTMLAndRaplceSymbols",
          (props) => {
            props.response && res([...props.response]);
            !props.response && rej([]);
          },
        );

        infinitelyWorker.postMessage({
          command: "parseHTMLAndRaplceSymbols",
          props: {
            pageName: currentPageId,
            projectId: +projectID,
          },
        });
      });

      console.log("elements : ", elements);

      return elements;
    };

    //pov-1 await getElements();

    editor.onReady(() => {
      const iframeEl = editor.Canvas.getFrameEl();
      const root = iframeEl.contentDocument.documentElement;
      const themes = projectData.themes;
      if (!themes) return;
      console.log('root and themes' , themes , root);
      
      root.setAttribute("data-theme", themes.default_theme);
      root.setAttribute("data-mode", themes.default_mode);
    });

    editor.trigger(InfinitelyEvents.pages.select);
    editor.trigger(InfinitelyEvents.pages.update);
    editor.trigger(InfinitelyEvents.pages.all);
    window.dispatchEvent(changePageName({ pageName: currentPageId }));
    // const parsed = editor.Parser.parseHtml(await getElements(), {
    //   asDocument: false,
    // });
    // let content = isArray(parsed.html) ? [...parsed.html] : [parsed.html];
    // console.log(content);
    if (justSendToWorker) {
      return await new Promise((res, rej) => {
        workerCallbackMaker(
          infinitelyWorker,
          "parseHTMLAndRaplceSymbols",
          async (props) => {
            editor.select(null);
            // editor.off("canvas:frame:load:body");
            await loadScripts(editor, projectData);
            // editor.on("canvas:frame:load:body", () => {
            //   attrsCallback(editor, projectData);
            // });
            editor.clearDirtyCount();
            console.log("parseHTMLAndRaplceSymbols props : ", props);
            res(props);
            onSend(
              [renderCssStyles(editor, cssCode), ...props.response],
              cssCode,
            );
            editor.on("component:remove:before", editor.removerBeforeHandler);
          },
        );

        infinitelyWorker.postMessage({
          command: "parseHTMLAndRaplceSymbols",
          props: {
            pageName: currentPageId,
            projectId: +projectID,
          },
        });
      });
    } else {
      editor.select(null);
      // editor.off("canvas:frame:load");
      // await loadScripts(editor, projectData);
      // editor.on("canvas:frame:load", () => {
      //   attrsCallback(editor, projectData);
      // });

      editor.clearDirtyCount();
      editor.on("component:remove:before", editor.removerBeforeHandler);
      // editor.Css.addRules(cssCode);
      return {
        components: [
          renderCssStyles(editor, cssCode),
          ...(await getElements()),
        ],
        // styles:editor.Parser.parseCss(cssCode)
      };
    }

    //pov-2[]
    //await getElements()
    // return [renderCssStyles(editor, cssCode), ...(await getElements())];
  };

  [current_symbol_rule, current_symbol_id, current_template_id].forEach(
    (item) => sessionStorage.removeItem(item),
  );

  return await loadCurrentPage();
};

/**
 *
 * @param {import('grapesjs').Editor} editor
 */
export const IDB = (editor) => {
  console.log("IDB.js Fired");

  const projectID = localStorage.getItem(current_project_id);
  const mainCreateObjectURLMethod = URL.createObjectURL;
  const willRevokedURLs = new Map();
  URL.createObjectURL = (obj) => {
    const url = mainCreateObjectURLMethod(obj);
    willRevokedURLs.set(url);
    return url;
  };

  let tId;
  editor.infDirty = 0;

  const clearTimeouts = () => {
    infinitelyWorker.postMessage({
      command: "clearTimeouts",
    });
    // console.log(
    //   `Timeouts : `,
    //   initSymbolTimout,
    //   loadTimeout,
    //   storeTimeout,
    //   appenderTimeout,
    //   screenshotTimout,
    //   updateThumbnailTimeout,
    // );

    initSymbolTimout && clearTimeout(initSymbolTimout);
    loadTimeout && clearTimeout(loadTimeout);
    storeTimeout && clearTimeout(storeTimeout);
    // appenderTimeout && clearTimeout(appenderTimeout);
    screenshotTimout && clearTimeout(screenshotTimout);
    updateThumbnailTimeout && clearTimeout(updateThumbnailTimeout);
  };

  editor.on("component:drag", () => {
    clearTimeouts();
  });

  if (!projectID) {
    console.error(`Error : No project id founded in local storage`);
    return;
  }

  editor.on("update", (update) => {
    // console.log("update : ", update, editor.infLoading);
    if (editor.infLoading) {
      editor.clearDirtyCount();
    }
  });

  editor.Storage.add("infinitely", {
    async load(options = {}) {
      console.log("loading options : ", options);
      loadTimeout && clearTimeout(loadTimeout);
      loadTimeout &&
        window.cancelIdleCallback &&
        cancelIdleCallback(loadTimeout);
      editor.infLoading = true;
      if (editor.getDirtyCount() > 0) {
        console.log(
          "loading state : ",
          editor.infLoading,
          editor.getDirtyCount.toString(),
        );

        const cnfrm = confirm(
          `There is changes not saved and you lost it after reload , Are you want to save changes ? `,
        );

        if (cnfrm) {
          await editor.store();
          const callback = async () => {
            await editor.load();
            editor.off(InfinitelyEvents.storage.storeEnd, callback);
          };
          editor.on(InfinitelyEvents.storage.storeEnd, callback);
          editor.StorageManager.setStepsBeforeSave(0);
          editor.clearDirtyCount();
          return;
        }
      }

      // editorStorageInstance.emit(InfinitelyEvents.storage.loadStart);
      editor.off("component:remove:before");

      editor.clearDirtyCount();
      clearTimeouts();

      reloadEditor(editor);
      // editor.on("style:change", () => {
      //   console.log("style changed");

      //   const css = editor.getCss({ avoidProtected: true });
      //   editor.setStyle(css); // Forces reordering
      // });

      return;
    },

    //Storinggg

    store(storeProps = {}) {
      if (storeTimeout) clearTimeout(storeTimeout);
      if (pageBuilderTimeout) clearTimeout(pageBuilderTimeout);
      if (editor.getDirtyCount() < 0) return;

      // editor.UndoManager.stop();

      // return new Promise((res, rej) => {
      storeTimeout = setTimeout(
        () => {
          const runStore = async () => {
            // console.log(
            //   "prrrrrrrrrrrrops from store : ",
            //   storeProps,
            //   editor.infLoading
            // );
            const projectSettings = getProjectSettings().projectSettings;
            editor.trigger(InfinitelyEvents.storage.storeStart);
            console.log("Before storing:", {
              dirty: editor.getDirtyCount(),
              steps: editor.StorageManager.getStepsBeforeSave(),
            });
            // if (!editor.getDirtyCount()) return;
            try {
              // toast.clearWaitingQueue({
              //   // containerId: `main-toast-container`,
              // });
              tId && toast.done(tId);
              if (!projectSettings.enable_auto_save) {
                tId = toast.loading(<ToastMsgInfo msg={"Saving..."} />);
              }

              editor.infStore = true;
              const projectID = +localStorage.getItem(current_project_id);
              const currentPageId = currentPageName;
              const currentSymbolId = sessionStorage.getItem(current_symbol_id);
              const projectData = await db.projects.get(projectID);
              const files = {};
              let tailwindcssStyle;

              const beforeunload = (e) => {
                e.preventDefault();
                e.returnValue = "";
              };

              if (projectSettings.enable_auto_save) {
                window.addEventListener("beforeunload", beforeunload);
              }

              // Handle global symbol
              const handleGlobalSymbol = async () => {
                if (!currentSymbolId) return false;

                const symbolEl = editor
                  .getWrapper()
                  .find(`[${inf_symbol_Id_attribute}="${currentSymbolId}"]`)[0];

                const symbolInf = getInfinitelySymbolInfo(editor.getSelected());
                const symbol = symbolInf?.symbol || symbolEl;
                const currentSymbol = projectData?.symbols?.[currentSymbolId];

                if (!symbol || !currentSymbol) return false;

                const content = symbol.toHTML({
                  withProps: true,
                  keepInlineStyle: true,
                });

                const style = getComponentRules({
                  editor,
                  cmp: symbol,
                  nested: true,
                }).stringRules;

                // minify(

                //   { restructure: true }
                // ).css;

                files[currentSymbol.pathes.content] = content;
                files[currentSymbol.pathes.style] = style;

                return true;
              };

              await handleGlobalSymbol();

              // Minify full CSS
              let cssCode = editor.getCss({
                avoidProtected: true,
                keepUnusedStyles: true,
              });

              // minify(
              //  ,
              //   { restructure: true }
              // ).css;

              if (projectSettings?.enable_tailwind) {
                const tailwindStyle = [
                  ...editor.Canvas.getDocument().head.querySelectorAll("style"),
                ].find((style) =>
                  style.innerHTML.includes(
                    "MIT License | https://tailwindcss.com",
                  ),
                );
                tailwindcssStyle = tailwindStyle?.innerHTML || "";
              }

              const wrapperEl = editor.getWrapper().getEl();

              const data = {
                pages: {
                  ...projectData.pages,
                  [currentPageId]: {
                    ...projectData.pages[currentPageId],
                    bodyAttributes:
                      editor.getWrapper().getAttributes() || wrapperEl
                        ? Object.fromEntries(
                            wrapperEl
                              .getAttributeNames()
                              .map((attrName) => [
                                attrName,
                                wrapperEl.getAttribute(attrName),
                              ]),
                          )
                        : (() => {
                            alert(
                              `There is problem when save wrapper attributes😩`,
                            );
                            return {};
                          })(),
                    symbols: (
                      editor
                        .getWrapper()
                        .find(`[${inf_symbol_Id_attribute}]`) || []
                    ).map(
                      (cmp) => cmp.getAttributes()[inf_symbol_Id_attribute],
                    ),
                  },
                },
              };
              editor.Parser.config.optionsHtml.allowScripts = false;

              files[`editor/pages/${currentPageId}.html`] = editor
                .getWrapper()
                .getInnerHTML({ withProps: true });
              editor.Parser.config.optionsHtml.allowScripts = true;

              files[`css/${currentPageId}.css`] = cssCode;
              console.log(
                "from store",
                currentPageName,
                `editor/pages/${currentPageId}.html`,
                editor.getWrapper().getInnerHTML({ withProps: true }),
              );

              const propsData = {
                data,
                files,
                projectSetting: projectSettings,
                tailwindcssStyle,
                projectId: projectID,
                pageName: currentPageId,
                pageUrl: `pages/${currentPageId}.html`,
                updatePreviewPages: true,
                editorData: {
                  canvasCss: editor.config.canvasCss,
                },
              };

              const props = {
                ...propsData,
                ...(isFunction(storeProps)
                  ? storeProps(propsData)
                  : storeProps || {}),
              };

              console.log("props will store : ", props);

              let afterSave;

              if (isFunction(props.afterSave)) {
                afterSave = props.afterSave;
                props.afterSave = null;
              }

              const onWorkerMessage = (ev) => {
                const { command, props: resProps } = ev.data;
                const isMatch = resProps?.projectId === projectID;

                if (
                  isMatch &&
                  (command === "updateDB" ||
                    command === "storeGrapesjsDataIfSymbols")
                ) {
                  infinitelyWorker.removeEventListener(
                    "message",
                    onWorkerMessage,
                  );

                  // if (currentSymbolId) {
                  //   editor.trigger("block:add");
                  //   editor.trigger("block:update");
                  // }
                  editor.trigger("block:add");
                  editor.trigger("block:update");
                  editor.infDirty = 0;
                  editor.clearDirtyCount();
                  console.log("Store complete:", { pageId: currentPageId });
                  console.timeEnd("storing end");
                  isFunction(afterSave) && afterSave();
                  editor.trigger(InfinitelyEvents.storage.storeEnd);
                  infinitelyWorker.reInit((worker) => {
                    worker.postMessage({
                      command: "initOPFS",
                      props: { id: opfs.id },
                    });
                  });
                  if (projectSettings.enable_auto_save) {
                    window.removeEventListener("beforeunload", beforeunload);
                  }
                  if (!projectSettings.enable_auto_save) {
                    toast.done(tId);
                    toast.success(
                      <ToastMsgInfo msg={`Project saved successfully👍`} />,
                    );
                  }

                  editor.Storage.setAutosave(projectSettings.enable_auto_save);
                  editor.infStore = false;
                  // reInitInfinitelyWorker();

                  // res(true);
                }
              };

              infinitelyWorker.addEventListener("message", onWorkerMessage);

              console.time("storing end");

              infinitelyWorker.postMessage({
                // command: currentSymbolId
                //   ? "storeGrapesjsDataIfSymbols"
                //   : "updateDB",
                command: "updateDB",
                props,
              });
            } catch (err) {
              console.error("Storage failed:", err);
              if (!projectSettings.enable_auto_save) {
                tId && toast.dismiss(tId);
                toast.error(<ToastMsgInfo msg={`Faild to save project 🙁`} />, {
                  progressClassName: "bg-[crimson]",
                });
              }
              // res(false);
            } finally {
              // editor.UndoManager.start();
            }
          };

          // if ("requestIdleCallback" in window) {
          //   requestIdleCallback(runStore);
          // } else {
          // }
          runStore();
        },
        getProjectSettings().projectSettings?.enable_auto_save ? 700 : 0,
      );
      // });

      return storeTimeout;
    },
  });
};

/**
 *
 * @param {import('grapesjs').Editor} editor
 * @param {string} cssCode
 */
export const renderCssStyles = (editor, cssCode) => {
  const styleCmp = editor.getWrapper()?.find?.(`[infinitely-style]`)?.[0];
  // editor.Css.clear({ avoidStore: true });
  styleCmp?.[0] && styleCmp.remove();
  // editor.addComponents(`<style infinitely-style">${cssCode}</style>`, {
  //   avoidStore: true,
  // });
  return `<style infinitely-style">${cssCode}</style>`;
};

/**
 *
 * @param {import('grapesjs').Editor } editor
 * @param {import('@/helpers/types').Project } projectData
 */
export const loadScripts = async (editor, projectData) => {
  const currentPageName = localStorage.getItem(current_page_id);
  const { projectSettings, set } = getProjectSettings();

  // Inject editor styles
  for (const styleDef of STYLE_DEFINITIONS.concat(DEV_STYLE_DEFINITIONS)) {
    if (isFunction(styleDef.condition) && !styleDef.condition(projectSettings))
      continue;
    editor.config.canvas.styles.push({
      name: styleDef.name,
      href: styleDef.localUrl,
      rel: "stylesheet",
    });
  }

  /**
   *
   * @param {{type:'styles' | 'scripts' , attributes:{name:string} , condition:boolean }} param0
   * @returns
   */
  const appendToHeader = ({ type = "", attributes = {}, condition = true }) => {
    if (!type) return;
    const isExist = editor.config.canvas[type].findIndex(
      (lib) => lib && typeof lib != "string" && lib?.name == attributes.name,
    );
    if (isExist == -1 && condition) {
      editor.config.canvas[type].push(attributes);
    } else if (isExist != -1 && !condition) {
      editor.config.canvas[type].splice(isExist, 1);
    }
  };

  editor.off("canvas:frame:load:body", loadFooterScriptsCallback);

  loadHeadScriptsCallback = (ev) => {
    console.log("from head event", ev);

    const jsHeaderLibs = projectData.jsHeaderLibs;
    const cssLibs = projectData.cssLibs;

    /**
     *
     * @param {import('@/helpers/types').LibraryConfig} lib
     * @returns
     */
    const getJsLib = (lib) => {
      const newObj = {
        src: lib.isCDN ? lib.fileUrl : lib.path, //URL.createObjectURL(lib.file), // jsToDataURL(lib.content),
        name: lib.name,
        async: lib.async,
        defer: lib.defer,
      };

      !lib.defer && delete newObj.defer;
      !lib.async && delete newObj.async;
      return newObj;
    };

    /**
     *
     * @param {import('@/helpers/types').LibraryConfig} lib
     * @returns
     */
    const getCssLib = (lib) => {
      // console.log("@!lib : ", lib.file);

      const url = lib.isCDN
        ? lib.fileUrl
        : // : lib.file.name.includes("global.css")
          // ? `/global.css`
          lib.path; //newObj;

      return {
        url,
        libData: lib,
      };
    };

    // console.log("scriiipts : ", jsHeaderLibs, editor.config.canvas.scripts);

    jsHeaderLibs.forEach((lib) => {
      const libData = getJsLib(lib);

      appendToHeader({
        type: "scripts",
        attributes: libData,
      });
    });
    // console.log("cssLibs : ", cssLibs);

    cssLibs.map((lib) => {
      if (typeof lib == "string") {
        return lib;
      }
      const libData = getCssLib(lib);

      appendToHeader({
        type: "styles",
        attributes: {
          href: libData.url,
          name: libData.libData.name,
        },
      });
    });

    appendToHeader({
      type: "styles",
      attributes: {
        href: `/global/global.css`,
        name: "global-css",
      },
    });

    appendToHeader({
      type: "styles",
      attributes: {
        href: `/css/infinitely-themes.css`,
        name: "infinitely-themes-css",
      },
      condition: isPlainObject(projectData?.themes),
    });

    const projectSetting = getProjectSettings().projectSettings;

    appendToHeader({
      type: "scripts",
      attributes: {
        src: `/scripts/tailwindcss.v4.js`,
        name: "tailwindcss.js",
      },
      condition: projectSetting.enable_tailwind,
    });
    appendToHeader({
      type: "styles",
      attributes: {
        href: `/styles/global-rules.css`,
        name: "global-rules.css",
        rel: "stylesheet",
      },
      condition: !projectSetting.enable_tailwind,
    });

    appendToHeader({
      type: "styles",
      attributes: {
        href: `${getPageURLException(currentPageName)}/css/fonts.css`,
        rel: "stylesheet",
        name: "fonts-installed",
      },
      condition: Object.values(projectData.fonts).length,
    });

    appendToHeader({
      type: "styles",
      attributes: {
        href: `/styles/will-change.css`,
        rel: "stylesheet",
        name: "will-change",
      },
      condition: !projectSettings.disable_will_change_in_editor,
    });
  };

  appendToHeader({
    type: "styles",
    attributes: {
      href: "/styles/optimize-outlines.css",
      rel: "stylesheet",
      name: "optimize-outlines",
    },
    condition: projectSettings.optimize_outlines,
  });

  loadFooterScriptsCallback = async (ev) => {
    // console.log("evoooooooooooo : ", ev.window.document.body);
    /**
     * @type {HTMLBodyElement}
     */
    const body = ev.window.document.body;
    const jsFooterLibs = projectData.jsFooterLibs; //.map(lib=>lib.file);
    // const globalScript = projectData.globalJs;
    // const localScript = projectData.pages[`${currentPageName}`].js;
    // const fragment = document.createDocumentFragment();
    // let lastScripts;
    // const allScripts = [
    //   ...jsFooterLibs,
    //   globalScript,
    //   localScript,
    //   ...mainScriptsForEditor,
    // ];
    /**
     * @param {import('@/helpers/types').LibraryConfig[] & Blob[] & string[]} array
     * @param {number} index
     * @param {(script: HTMLScriptElement, lib: import('@/helpers/types').LibraryConfig & Blob & string) => void} callback
     * @returns {Promise<boolean>}
     */
    const appendScript = async (
      array = [],
      index = 0,
      callback = (script, lib) => {},
    ) => {
      if (index > array.length - 1) return true;
      const script = document.createElement("script");
      const lib = array[index];
      attrsCallback(editor, projectData);

      try {
        callback(script, lib);
        // console.log(await (await fetch(`/keep-alive`)).text());
        console.log("Appending script:", script.src);

        if (!script.src) {
          console.warn("Skipping script with empty src:", lib);
          return await appendScript(array, index + 1, callback);
        }

        if (!body) {
          console.error("Body element is undefined");
          return false;
        }

        // editor.getWrapper().find(`script[src="${script.src}"]`).forEach(script=>script.remove());

        body.appendChild(script);

        return await new Promise((res) => {
          const loadCb = async () => {
            console.log(`Script loaded: ${script.src}`);
            script.removeEventListener("load", loadCb);
            res(await appendScript(array, index + 1, callback));
          };
          script.addEventListener("load", loadCb);

          const errCb = async (ev) => {
            console.error(`Error loading script: ${script.src}`, ev);
            script.removeEventListener("error", errCb);
            res(await appendScript(array, index + 1, callback)); // Continue on error
          };
          script.addEventListener("error", errCb);
        });
      } catch (err) {
        console.error(
          `Unexpected error in appendScript for ${script.src}:`,
          err,
        );
        return await appendScript(array, index + 1, callback); // Continue on error
      }
    };

    // Usage example
    await appendScript(jsFooterLibs, 0, (script, lib) => {
      if (lib.isCDN) {
        script.src = lib.fileUrl;
        script.setAttribute("name", lib.name);
      } else {
        script.src = lib.path;
        script.setAttribute("name", lib.name);
      }
      lib?.async && script.setAttribute("async", "");
      lib?.defer && script.setAttribute("defer", "");
    });

    await appendScript(["/global/global.js"], 0, (script, lib) => {
      script.src = lib;
    });

    for (const scriptDef of SCRIPT_DEFINITIONS) {
      if (
        isFunction(scriptDef.condition) &&
        !scriptDef.condition(projectSettings)
      )
        continue;
      if (isBoolean(scriptDef.is_dev) && !scriptDef.is_dev) continue;

      await appendScript([scriptDef.localUrl], 0, (script, lib) => {
        script.src = lib;
        if (isPlainObject(scriptDef.attributes)) {
          for (const attr in scriptDef.attributes) {
            script.setAttribute(attr, scriptDef.attributes[attr]);
          }
        }
        script.setAttribute("name", scriptDef.name);
      });
    }

    for (const scriptDef of DEV_SCRIPT_DEFINITIONS) {
      if (
        isFunction(scriptDef.condition) &&
        !scriptDef.condition(projectSettings)
      )
        continue;

      await appendScript([scriptDef.localUrl], 0, (script, lib) => {
        script.src = lib;
        if (isPlainObject(scriptDef.attributes)) {
          for (const attr in scriptDef.attributes) {
            script.setAttribute(attr, scriptDef.attributes[attr]);
          }
        }
        script.setAttribute("name", scriptDef.name);
      });
    }

    // await appendScript(mainScriptsForEditor, 0, (script, lib) => {
    //   script.src = lib;
    // });

    // projectSettings.enable_spline_viewer &&
    //   (await appendScript(
    //     [`https://unpkg.com/@splinetool/viewer@1.10.27/build/spline-viewer.js`],
    //     0,
    //     (script, lib) => {
    //       script.src = lib;
    //       script.type = "module";
    //       script.setAttribute("name", "spline-viewer.js");
    //     },
    //   ));

    // projectSettings.enable_swiperjs &&
    //   (await appendScript(
    //     [
    //       "https://cdn.jsdelivr.net/npm/swiper@latest/swiper-bundle.min.js",
    //       "https://cdn.jsdelivr.net/npm/swiper@latest/swiper-element-bundle.min.js",
    //     ],
    //     0,
    //     (script, lib) => {
    //       script.src = lib;
    //     },
    //   ));

    // !projectSettings.disable_will_change_in_editor &&
    //   (await appendScript(["/scripts/willChange.js"], 0, (script, lib) => {
    //     script.src = lib;
    //   }));

    // projectSettings.optimize_outlines &&
    //   (await appendScript(
    //     ["/scripts/optimizeOutlines.js"],
    //     0,
    //     (script, lib) => {
    //       script.src = lib;
    //       script.setAttribute("name", "optimize-outlines");
    //     },
    //   ));

    await appendScript(
      [
        `${currentPageName === "index" ? `./js/` : `../js/`}${currentPageName}.js`,
      ],
      0,
      (script, lib) => {
        script.src = lib;
      },
    );

    editor.off("canvas:frame:load:body", loadFooterScriptsCallback);
    loadFooterScriptsCallback = null;
    loadHeadScriptsCallback = null;
    loadMainScriptsCallback = null;
  };

  loadHeadScriptsCallback();

  editor.on("canvas:frame:load:body", loadFooterScriptsCallback);
};
