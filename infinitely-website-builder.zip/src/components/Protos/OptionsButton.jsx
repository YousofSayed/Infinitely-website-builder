import { addClickClass, uniqueID } from "@/helpers/cocktail";
import { SmallButton } from "@/components/Editor/Protos/SmallButton";
import { Icons } from "@/components/Icons/Icons";
import { unwrap } from "million/react";
import React, { useRef, useState, useTransition } from "react";
import { Tooltip } from "react-tooltip";

// million-ignore







// million-ignore
/**
 * @param {import('react').HTMLAttributes<HTMLDivElement>} [props]
 * @returns {JSX.Element}
 */
export const OptionsButton = ({
  children,
  place = "bottom-end",
  onClick,
  notify,
  icon,
  notifyBg = "bg-brand-primary",
  ...props
}) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [, startTransition] = useTransition();
  const id = useRef(uniqueID());

  const handleClick = (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    startTransition(() => setShowTooltip((prev) => !prev));
    addClickClass(ev.currentTarget, "click");
    onClick?.(ev);
  };

  const handleTooltipClick = (ev) => {
    console.log("target : ", ev.target);
    if (!(ev.target && ev.target.tagName == "INPUT")) {
      ev.preventDefault();
    }
    ev.stopPropagation();
  };

  return (
    <div
      className="flex justify-center items-center w-fit h-full flex-shrink flex-grow-0"
      onClick={(ev) => {
        ev.stopPropagation();
        // ev.preventDefault();
      }}
    >
      <SmallButton
        onClick={handleClick}
        id={id.current}
        {...props}
        className={`relative w-full h-full flex justify-center items-center bg-transparent hover:bg-transparent border-none  ${props.className || ""}`}
      >
        {icon ? icon : Icons.options({ fill: "#fff" })}
        {notify && (
          <div
            className={`absolute w-[10px] h-[10px] ${notifyBg} rounded-full right-0 top-0`}
          ></div>
        )}
      </SmallButton>

      {Boolean(children) && (
        <Tooltip
          id={`tooltip-${id.current}`}
          className="w-fit p-[unset] z-[100] shadow-lg bg-surface-tertiary shadow-slate-950"
          style={{
            boxShadow: "0px 0px 10px 1px #020617",
            padding: "5px",
            backgroundColor: "#1e293b",
          }}
          positionStrategy="fixed"
          anchorSelect={`#${id.current}`}
          place={place}
          clickable
          isOpen={showTooltip}
          setIsOpen={setShowTooltip}
          openEvents={{
            click: false,
            dblclick: false,
            focus: false,
            mousedown: false,
            mouseenter: false,
            mouseover: false,
          }}
          opacity={1}
          openOnClick
          closeEvents={{
            click: false,
            dblclick: false,
            blur: false,
            mouseout: false,
            mouseup: false,
            mouseleave: false,
          }}
        >
          <div onClick={handleTooltipClick}>{children}</div>
        </Tooltip>
      )}
    </div>
  );
};
