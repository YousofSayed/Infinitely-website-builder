import React from 'react'

export const AIInterface = () => {
  return (
    <div>AIInterface</div>
  )
}
