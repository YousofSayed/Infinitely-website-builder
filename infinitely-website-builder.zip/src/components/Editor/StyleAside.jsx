import { InfinitelyEvents } from "@/constants/infinitelyEvents";
import { styles } from "@/constants/styles";
import {
  animationsState,
  cmpRulesState,
  currentElState,
  isAnimationsChangedState,
  mediaConditionState,
  ruleState,
  selectorState,
  showAnimationsBuilderState,
  showComponentsInLeftPanelState,
  showStylesBuilderForMotionBuilderState,
} from "@/helpers/atoms";
import { parse } from "@/helpers/cocktail";
import {
  getComponentRules,
  getCurrentMediaDevice,
  getCurrentSelector,
  toKebabCase,
} from "@/helpers/functions";
import { useRemoveCurrentMedia } from "@/hooks/useRemoveCurrentMedia";
import { useUpdateInputValue } from "@/hooks/useUpdateInputValue";
import { Accordion } from "@/components/Protos/Accordion";
import { AccordionItem } from "@/components/Protos/AccordionItem";
import { OptionsButton } from "@/components/Protos/OptionsButton";
import { AddMultiValuestoSingleProp } from "@/components/Editor/Protos/AddMultiValuestoSingleProp";
import { Color } from "@/components/Editor/Protos/Color";
import { DirectionsModel } from "@/components/Editor/Protos/DirectionsModel";
import { FitTitle } from "@/components/Editor/Protos/FitTitle";
import { MiniTitle } from "@/components/Editor/Protos/MiniTitle";
import { MultiChoice } from "@/components/Editor/Protos/MultiChoice";
import { MultiFunctionProp } from "@/components/Editor/Protos/MultiFunctionProp";
import { Property } from "@/components/Editor/Protos/Property";
import { SelectClass } from "@/components/Editor/Protos/SelectClass";
import { SelectState } from "@/components/Editor/Protos/SelectState";
import { SelectStyle } from "@/components/Editor/Protos/SelectStyle";
import { SmallButton } from "@/components/Editor/Protos/SmallButton";
import { ToastMsgInfo } from "@/components/Editor/Protos/ToastMsgInfo";
import { useAutoAnimate } from "@formkit/auto-animate/react";
import { useEditorMaybe } from "@grapesjs/react";
import {
  cloneDeep,
  isArray,
  isBoolean,
  isString,
  random,
  uniqueId,
} from "lodash";
import { For } from "million/react";
import React, {
  memo,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { ErrorBoundary } from "react-error-boundary";
import { toast } from "react-toastify";
import { useRecoilState, useRecoilValue } from "recoil";
import { Icons } from "@/components/Icons/Icons";

const SelectElementToStyle = () => (
  <h1 className="text-slate-400 custom-font-size text-center animate-pulse capitalize font-semibold bg-surface-secondary rounded-lg p-2">
    Select element to style
  </h1>
);

const StyleAccordion = () => {
  // const showAnimeBuilder = useRecoilValue(showAnimationsBuilderState);
  const [notifires, setNotifires] = useState({});
  const showAnimationsBuilder = useRecoilValue(showAnimationsBuilderState);
  const [showsComponents, setShowsComponents] = useRecoilState(
    showComponentsInLeftPanelState,
  );

  const allCssProps = useRef(
    Object.fromEntries(
      Object.entries(styles).map(([key, style]) => {
        // style.forEach((props) => {
        //   if (props.cssProp) {
        //     isArray(props.cssProp)
        //       ? prev.push(...props.cssProp)
        //       : prev.push(props.cssProp);
        //   }

        //   if (props.directions) {
        //     console.log(
        //       "all css props : directions ,",
        //       Object.values(props.directions)
        //     );

        //     prev.push(...Object.values(props.directions));
        //   }
        // });
        const cssProps = style.reduce((prev, { cssProp, directions }) => {
          if (cssProp) {
            isArray(cssProp) ? prev.push(...cssProp) : prev.push(cssProp);
          }

          if (directions) {
            console.log(
              "all css props : directions ,",
              Object.values(directions),
            );

            prev.push(...Object.values(directions));
          }

          return prev;
        }, []);
        return [key, cssProps];
      }),
    ),
  );

  function notifing(styles) {
    let newNotf = {};
    // styles = styles.framesStyles ? styles.framesStyles : styles;
    console.log("frames : ", styles, styles.framesStyles);

    for (const key in styles) {
      const kebabProp = toKebabCase(key);
      for (const [ctg, props] of Object.entries(allCssProps.current)) {
        if (styles[key] && props.includes(kebabProp)) {
          newNotf[ctg] = true;
        }
      }
    }
    console.log("notifires : ", newNotf, styles);

    setNotifires(newNotf);
  }

  console.log("all css props : ", allCssProps.current);
  function getAllStyles(styles) {
    // if (showAnimationsBuilder) {
    //   // setNotifires({});
    //   // return;
    // }
    notifing(styles);
  }

  useUpdateInputValue({
    getAllStyles,
  });

  // let stylesClone = cloneDeep(styles);
  // showAnimationsBuilder && delete stylesClone['Animation'];

  const filteredStyles = useMemo(() => {
    if (!showsComponents.animationsBuilder) return styles;

    const { Animation, ...rest } = styles;
    return rest;
  }, [styles, showsComponents.animationsBuilder]);

  return (
    <Accordion>
      <For each={Object.entries(filteredStyles)}>
        {([key, styles], i) => (
          <AccordionItem key={i} title={key} notify={notifires[key]}>
            <ErrorBoundary fallbackRender={SelectElementToStyle}>
              <section
                className="flex flex-col gap-1 w-full  bg-surface-secondary rounded-lg animate-go-to auto-animate"
                inf-css-tokens-container="true"
              >
                <For each={styles}>
                  {(
                    {
                      cssProp,
                      type,
                      title,
                      separator,
                      keywords,
                      directions,
                      choices,
                      placeholder,
                      splitHyphen,
                      Component,
                      special,
                      units,
                    },
                    i,
                  ) => (
                    <section
                      title={cssProp}
                      key={i}
                      className="flex flex-col gap-1 w-full p-1 bg-surface-secondary rounded-lg"
                    >
                      {type == "title" && <MiniTitle>{title}</MiniTitle>}
                      {type == "property" && (
                        <Property
                          cssProp={cssProp}
                          label={title}
                          placeholder={placeholder || title}
                          special={special}
                        />
                      )}
                      {type == "select" && (
                        <SelectStyle
                          cssProp={cssProp}
                          label={title}
                          placeholder={placeholder || title}
                          keywords={keywords}
                          splitHyphen={splitHyphen}
                        />
                      )}
                      {type == "color" && (
                        <Color
                          label={title}
                          cssProp={cssProp}
                          placeholder={placeholder || title}
                        />
                      )}
                      {type == "directions" && (
                        <DirectionsModel
                          tProp={directions.tProp}
                          rProp={directions.rProp}
                          bProp={directions.bProp}
                          lProp={directions.lProp}
                        />
                      )}
                      {type == "multi-choice" && (
                        <MultiChoice
                          cssProp={cssProp}
                          choices={choices}
                          label={title}
                        />
                      )}
                      {type == "multi-function-prop" && (
                        <MultiFunctionProp
                          cssProp={cssProp}
                          placeholder={placeholder || title}
                          keywords={keywords}
                          units={units}
                        />
                      )}
                      {type == "multi-values-for-single-prop" && (
                        <AddMultiValuestoSingleProp
                          cssProp={cssProp}
                          label={title}
                          keywords={keywords}
                          placeholder={placeholder || title}
                          separator={separator}
                        />
                      )}
                      {type == "custom" && <Component />}
                    </section>
                  )}
                </For>
              </section>
            </ErrorBoundary>
          </AccordionItem>
        )}
      </For>
    </Accordion>
  );
};
/**
 *
 * @param {{className:string}} param0
 * @returns
 */
export const StyleAside = memo(({ className }) => {
  // const [currentEl, setCurrentEl] = useState();
  const editor = useEditorMaybe();
  const showAnimeBuilder = useRecoilValue(showAnimationsBuilderState);
  const [currentEl, setCurrentEl] = useRecoilState(currentElState);
  const [globalRule, setGlobalRule] = useRecoilState(ruleState);
  const [selector, setSelector] = useRecoilState(selectorState);
  const [showClasses, setShowClasses] = useState(false);
  const [animateRef] = useAutoAnimate();
  const [key, setKey] = useState(uniqueId("Accordion-id-"));
  const [cmpRules, setCmpRules] = useRecoilState(cmpRulesState);
  // const [globalRule , setGlobalRule] = useRecoilState(ruleState);
  const [notifyStates, setNotifyStates] = useState(false);
  const [notifyClasses, setNotifyClasses] = useState(false);
  const [mediaCondTitle, setMediaCondTitle] = useState("");
  const [mediaCond, setMediaCond] = useRecoilState(mediaConditionState);
  const [isAnimationsChanged, setAnimationsChanged] = useRecoilState(
    isAnimationsChangedState,
  );
  const [animations, setAnimations] = useRecoilState(animationsState);
  const [showAnimBuilder, setShowAnimBuilder] = useRecoilState(
    showAnimationsBuilderState,
  );
  const [showStylesBuilder, setShowStylesBuilder] = useRecoilState(
    showStylesBuilderForMotionBuilderState,
  );
  const [showsComponents, setShowsComponents] = useRecoilState(
    showComponentsInLeftPanelState,
  );

  const removeCurrentMediaRule = useRemoveCurrentMedia();

  useLayoutEffect(() => {
    const showVal =
      globalRule.ruleString.includes("::before") ||
      !globalRule.ruleString.includes("::after");
    setShowClasses(showVal);
  }, [globalRule]);

  useEffect(() => {
    if (!editor) return;
    const sel = editor.getSelected();
    if (!sel) {
      setNotifyClasses(false);
      return;
    }
    const classes = sel.getClasses() || [];
    setNotifyClasses(classes.length > 0);
  }, [editor, currentEl]);

  //settingGlobalRuleTitle
  useEffect(() => {
    if (!editor) return;
    const sle = editor.getSelected();
    if (!sle) return;
    const settingGlobalRuleTitle = () => {
      let currentSelector = getCurrentSelector(selector, sle);
      const currentMedia = getCurrentMediaDevice(editor);
      const device = editor.Devices.get(editor.getDevice());
      const mediaPx = device.attributes.widthMedia;
      // const mediaCond = editor.getConfig().mediaCondition;
      const selectorWithRule = `${currentSelector}${globalRule.ruleString}`;
      const mediaConditionTitle = `${editor.getConfig().mediaCondition || mediaCond} ${
        mediaPx && mediaCond ? `(${mediaPx})` : ""
      } ${editor.config.mediaCondition ? ":" : ""} `;

      let title = ` ${device.getName()?.toLowerCase?.() === "desktop" ? "" : mediaConditionTitle}
    ${selectorWithRule}`;

      const edRule = editor.CssComposer.getRule(selectorWithRule.trim(), {
        ...currentMedia,
      });

      const rulesOfCurrentSle = getComponentRules({
        editor,
        cmp: editor.getSelected(),
        nested: true,
      });

      console.log(
        "edRule",
        edRule,
        selectorWithRule,
        rulesOfCurrentSle,
        /(:|::)\w+/gi.test(selectorWithRule),
      );

      if (
        !edRule &&
        !/(:|::)\w+/gi.test(selectorWithRule) &&
        rulesOfCurrentSle.rules.length &&
        rulesOfCurrentSle.rules[0].states
      ) {
        setMediaCondTitle(`There is styles in states for ${selectorWithRule}`);
      } else if (edRule) {
        setMediaCondTitle(title);
      } else {
        setMediaCondTitle("");
      }
      console.log(`From settingGlobalRuleTitle`);
    };

    settingGlobalRuleTitle();
    editor.on("change:device", settingGlobalRuleTitle);
    // editor.on(InfinitelyEvents.ruleTitle.update, settingGlobalRuleTitle);

    return () => {
      editor.off("change:device", settingGlobalRuleTitle);
      // editor.off(InfinitelyEvents.ruleTitle.update, settingGlobalRuleTitle);
    };
  }, [cmpRules, editor, currentEl, globalRule, mediaCond]);

  useEffect(() => {
    setKey(uniqueId("Accordion-id-"));
  }, [showsComponents.animationsBuilder]);

  useEffect(() => {
    if (!editor) {
      setNotifyStates(false);
      return;
    }
    if (!editor.getSelected()) {
      setNotifyStates(false);
      return;
    }

    const currentSelector = getCurrentSelector(selector, editor.getSelected());
    console.log(
      "seco currentSelector for states notify : ",
      currentSelector,
      selector,
    );

    // for (const rule of cmpRules) {
    //   console.log(`seco : `  , rule.states && currentSelector && rule.rule.startsWith(currentSelector));

    //   if (rule.states && currentSelector && rule.rule.startsWith(currentSelector)) {
    //     return;
    //   }
    // }
    setNotifyStates(
      cmpRules.some(
        (rule) =>
          rule.states &&
          currentSelector &&
          rule.rule.startsWith(currentSelector),
      ),
    );
  }, [cmpRules, currentEl, editor, selector]);

  const copyStyles = async () => {
    if (!editor) return;
    const slEL = editor?.getSelected();
    const Media = getCurrentMediaDevice(editor);
    const currentSelector = getCurrentSelector(selector, slEL);

    //==========
    const outPut = editor.Css.getRule(
      `${currentSelector}${globalRule.ruleString}`,
      { ...Media },
    )?.toJSON()?.style;

    console.log("style output : ", outPut, JSON.stringify(outPut));
    if (!outPut) {
      toast.warn(
        <ToastMsgInfo
          msg={`There is no styles to copy in ${currentSelector} 🥺`}
        />,
      );
      return;
    }
    await navigator.clipboard.writeText(JSON.stringify(outPut));
    toast.success(<ToastMsgInfo msg={`Styles copied successfully 👍`} />);
    return outPut || {};
  };

  const pasteStyles = async () => {
    const styles = parse(await navigator.clipboard.readText());
    if (!styles) {
      toast.error(<ToastMsgInfo msg={`Styles not valied 🥺`} />);
      return;
    }
    const cnfrm = confirm(`Are You Sure To Overwrite Styles ?`);
    if (!cnfrm) return;
    const slEL = editor?.getSelected();
    const Media = getCurrentMediaDevice(editor);
    const currentSelector = getCurrentSelector(selector, slEL);

    const rule = editor.Css.getRule(
      `${currentSelector}${globalRule.ruleString}`,
      { ...Media },
    );

    editor.CssComposer.remove(rule);
    editor.CssComposer.setRule(
      `${currentSelector}${globalRule.ruleString}`,
      styles,
      {
        ...Media,
        addStyles: true,
        validate: false,
        // inline:true,
        addStyle: true,
      },
    );

    setCurrentEl({
      currentEl: JSON.parse(JSON.stringify(slEL)),
    });
  };

  return (
    <section
      // key={key}
      // ref={animateRef}
      className="flex flex-col w-full h-full gap-2 mt-2 animate-go-to will-change-[transform,opacity] auto-animate"
    >
      {!showsComponents.animationsBuilder && !showsComponents.stylesBuilder && (
        <section className="flex gap-2">
          <FitTitle
            isShowTooltib={Boolean(mediaCondTitle)}
            className={`custom-font-size w-full text-base ${
              !mediaCondTitle &&
              "justify-center font-bold animate-pulse will-change-[transform,opacity] capitalize"
            }  text-ellipsis whitespace-nowrap overflow-hidden flex items-center py-2`}
          >
            {mediaCondTitle || "There is no rule yet"}
          </FitTitle>

          <SmallButton
            className="hover:bg-[crimson!important] bg-surface-tertiary"
            showTooltip
            tooltipTitle="Delete Current Rule"
            onClick={() => {
              removeCurrentMediaRule();
            }}
          >
            {Icons.trash("white")}
          </SmallButton>

          <OptionsButton className="w-[35p] h-full bg-surface-tertiary">
            <section className="flex flex-col items-center gap-3">
              <SmallButton
                className="h-[35px]"
                showTooltip
                tooltipTitle="Copy Styles"
                onClick={() => {
                  copyStyles();
                }}
              >
                {Icons.copy({ fill: "white" })}
              </SmallButton>
              <SmallButton
                className="h-[35px]"
                showTooltip
                tooltipTitle="Paste Styles"
                onClick={() => {
                  pasteStyles();
                }}
              >
                {Icons.paste({ fill: "white" })}
              </SmallButton>
            </section>
          </OptionsButton>
        </section>
      )}
      {/* {!showAnimeBuilder && (
        <>
          <DetailsNormal className="bg-surface-main " label={"Classes"}>
            <SelectClass />
          </DetailsNormal>

          <DetailsNormal label={"States"} className="bg-surface-main">
            <SelectState />
          </DetailsNormal>
        </>
      )}

       <DetailsNormal
          label={"layout"}
        >
          <Layout />
        </DetailsNormal> */}

      {/* {!showAnimeBuilder && (
        <InfAccordion>
          <AccordionItem
            title={"classes"}
            slotProps={{ transition: { unmountOnExit: true } }}
          >
            {showClasses ? <SelectClass /> : null}
          </AccordionItem>

          <AccordionItem
            key={2}
            title={"states"}
            slotProps={{ transition: { unmountOnExit: true } }}
          >
            <SelectState />
          </AccordionItem>
        </InfAccordion>
      )} */}

      <section className=" flex flex-col gap-2 auto-animate animate-go-to">
        {!showsComponents.animationsBuilder &&
          !showsComponents.stylesBuilder && (
            <Accordion>
              <AccordionItem title={"classes"} notify={notifyClasses}>
                {showClasses ? <SelectClass /> : null}
              </AccordionItem>

              <AccordionItem key={2} title={"states"} notify={notifyStates}>
                <SelectState />
              </AccordionItem>
            </Accordion>
          )}

        <StyleAccordion />
      </section>
    </section>
  );
});
