import { Icons } from "@/components/Icons/Icons";
import { Input } from "@/components/Editor/Protos/Input";
import { Select } from "@/components/Editor/Protos/Select";
import { SmallButton } from "@/components/Editor/Protos/SmallButton";
import { TinyButton } from "@/components/Editor/Protos/TinyButton";
import React, { memo, useEffect, useMemo, useState } from "react";

/**
 *
 * @param {{className:string , itemRef:any, addClassName:string , id:string, delClassName:string, inputClassName:string, emptyInputValueAfterClick:boolean, showSelectMenu:boolean , keywords :string[] , value:string , setValue:(any)=>void , placeholder:string, onAllForSelect:(value:string)=>void, showInput:boolean, onInput:(value:string)=>void, onEnterPress:(value:string)=>void , onItemClicked:(value:string)=>void , onAddClick: (ev : MouseEvent , value:string)=>void , onDeleteClick:(ev : MouseEvent)=>void}} param0
 * @returns
 */

export const Adder = memo((
  ({
    id = "",
    children, 
    itemRef,
    className,
    addClassName = "",
    delClassName = "",
    inputClassName = "",
    placeholder = "",
    showInput = false,
    showSelectMenu = false,
    emptyInputValueAfterClick = false,
    keywords = [],
    value,
    setValue = (value)=>{},
    onInput = (value) => {},
    onItemClicked = (value) => {},
    onEnterPress = (value) => {},
    onAllForSelect = (value) => {},
    onAddClick = (_) => {},
    onDeleteClick = (_) => {},
  }) => {
    const [val, setVal] = useState(value);
    useMemo(() => {
      if(!value && !val)return
      console.log("adder st", value);
      setVal(value);
    }, [value]);

    return (
      <section
        id={id}
        ref={itemRef}
        className={`flex w-full flex-col gap-2 p-2 rounded-lg  ${
          className ? className : "bg-surface-secondary"
        } relative`}
      >
        {children ? <section className="">{children}</section> : null}
        {/* {children} */}
        <section className="flex items-center  text-text-primary font-semibold   justify-end  w-full  gap-2   bottom-[-40px] right-[0]  ">
          {showInput && (
            <input
              className={`p-2 rounded-lg w-[calc(100%-80px)] outline-none border-2 border-transparent focus:border-blue-600 ${
                inputClassName ? inputClassName : "bg-surface-secondary"
              }`}
              placeholder={placeholder || "Add Value"}
              onInput={(ev) => {
                onInput(ev.target.value);
              }}
            />
          )}

          {showSelectMenu && (
            <Select
              onInput={onInput}
              onEnterPress={onEnterPress}
              onItemClicked={onItemClicked}
              onAll={(value) => {
                onAllForSelect(value);
              }}
              // onEnterPress={()=>{ emptyInputValueAfterClick && setVal("");}}
              // onItemClicked={()=>{ emptyInputValueAfterClick && setVal("");}}
              keywords={keywords}
              className={`${inputClassName} `}
              placeholder={placeholder}
              value={val}
              setValue={setValue}
            />
          )}

          <TinyButton
            title="Delete button"
            className={`shrink-0 ${delClassName}`}
            onClick={(ev) => {
              onDeleteClick(ev);
            }}
          >
            {Icons.delete("white")}
          </TinyButton>

          <TinyButton
            title="Add Button"
            className={`shrink-0 ${addClassName}`}
            onClick={(ev) => {
              onAddClick(ev, val);
              emptyInputValueAfterClick && setVal("");
            }}
          >
            {Icons.plus("white")}
          </TinyButton>
        </section>
      </section>
    );
  }
));
