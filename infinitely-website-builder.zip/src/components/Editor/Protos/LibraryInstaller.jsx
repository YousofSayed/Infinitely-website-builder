import { JSLibrariesType } from "@/helpers/jsDocs";
import { Loader } from "@/components/Loader";
import { VirtosuoVerticelWrapper } from "@/components/Protos/VirtosuoVerticelWrapper";
import { Input } from "@/components/Editor/Protos/Input";
import { JsLibrary } from "@/components/Editor/Protos/JsLibrary";
import { ToastMsgInfo } from "@/components/Editor/Protos/ToastMsgInfo";
import { For } from "million/react";
import React, { useMemo, useRef, useState } from "react";
import { toast } from "react-toastify";
import { Virtuoso } from "react-virtuoso";
import { useCDNLibraries } from "@/queries/editor.queries";
import { useAutoAnimate } from "@formkit/auto-animate/react";
import { useLiveQuery } from "dexie-react-hooks";
import { getProjectData } from "@/helpers/functions";

//million-ignore
export const LibraryInstaller = () => {
  // const [libraries, setLibraries] = useState(JSLibrariesType);
  const [showLoader, setShowLoader] = useState(false);
  const timeout = useRef();
  const [params, setParams] = useState({ search: "" });
  const { data: dataCDNLibraries, isLoading: isLoadingCDNLibraries } =
    useCDNLibraries(params);
  const projectData = useLiveQuery(async () => {
    return await getProjectData();
  });

  const libraries = useMemo(() => {
    if (isLoadingCDNLibraries) {
      return [];
    }
    return (
      dataCDNLibraries?.results?.filter?.(
        (lib) =>
          lib?.latest &&
          (lib.latest.endsWith("js") || lib.latest.endsWith("css")) &&
          !projectData?.jsHeaderLibs?.find?.((dLib) => dLib.nameWithoutExt == lib.name) &&
          !projectData?.jsFooterLibs?.find?.((dLib) => dLib.nameWithoutExt == lib.name) &&
          !projectData?.cssLibs?.find?.((dLib) => dLib.nameWithoutExt == lib.name),
      ) || []
    );
  }, [isLoadingCDNLibraries, dataCDNLibraries, projectData]);

  const [animatedRef] = useAutoAnimate();

  // const searchOnlibrary = async (libraryName = "") => {
  //   try {
  //     if (!libraryName) {
  //       setShowLoader(false);
  //       setLibraries([]);
  //       return;
  //     }
  //     setShowLoader(true);
  //     const searchEndPoint = `https://api.cdnjs.com/libraries?search=${libraryName}&fields=filename,description,version,github`;
  //     const response = (await fetch(searchEndPoint)).json();
  //     /**
  //      * @type {import('@/helpers/types').JSLibrary[]}
  //      */
  //     const results = await (await response).results;
  //     console.log(results);

  //     setLibraries(
  //       results.filter(
  //         (lib) =>
  //           lib?.latest &&
  //           (lib.latest.endsWith("js") || lib.latest.endsWith("css")),
  //       ),
  //     );
  //     setShowLoader(false);
  //   } catch (error) {
  //     toast.error(<ToastMsgInfo msg={"Faild To Get Library"} />);
  //     setShowLoader(false);
  //     setLibraries([]);
  //     throw new Error(`From Library Installer : ${error}`);
  //   }
  // };

  const onInput = (value) => {
    timeout.current && clearTimeout(timeout.current);
    timeout.current = setTimeout(async () => {
      // await searchOnlibrary(value);
      setParams({ search: value });
    }, 300);
  };

  return (
    <section className="p-1 h-full">
      {/* <header className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-extrabold text-center mb-10 text-blue-600">
          JavaScript Library Installer
        </h1>
      </header> */}

      <main className="flex flex-col gap-2 h-full" ref={animatedRef}>
        <div className=" sticky top-0 left-0">
          <Input
            id="search"
            type="text"
            placeholder="Search by library name..."
            className="w-full  p-2 rounded-lg bg-surface-main border border-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none  font-semibold placeholder-slate-500"
            onInput={(ev) => {
              onInput(ev.target.value);
            }}
          />
          <div className="absolute  inset-y-0 right-3 flex items-center gap-2">
            {isLoadingCDNLibraries && <Loader width={15} height={15} />}
            <svg
              width={27.5}
              height={27.5}
              className=" text-slate-500 shrink-0"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M21 21l-4.35-4.35m-6.65 1.35a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15z"
              />
            </svg>
          </div>
        </div>

        {/* <section className="grid grid-cols-3 gap-2">
          <For each={libraries}>
            {(lib,i)=><JsLibrary key={i} library={lib} />}
          </For>
        </section> */}

        {/* <section className="h-full overflow-auto  flex flex-col gap-2"> */}
        <Virtuoso
          className="overflow-y-auto hideScrollBar"
          totalCount={libraries.length}
          itemContent={(i) => {
            const lib = libraries[i];
            return <JsLibrary key={i} library={lib} />;
          }}
          components={{
            Item: (props) => (
              <div className="flex flex-col my-2 " {...props}></div>
            ),
          }}
        />
        {/* </section> */}
      </main>
    </section>
  );
};
