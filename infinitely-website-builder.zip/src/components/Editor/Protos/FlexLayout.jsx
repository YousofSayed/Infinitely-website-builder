import { alignSelfValues } from "@/constants/cssProps";
import { currentElState } from "@/helpers/atoms";
import { getIconForMultiChoice } from "@/helpers/functions";
import { useUpdateInputValue } from "@/hooks/useUpdateInputValue";
import { Icons } from "@/components/Icons/Icons";
import { P } from "@/components/Protos/P";
import { FitTitle } from "@/components/Editor/Protos/FitTitle";
import { MultiChoice } from "@/components/Editor/Protos/MultiChoice";
import { Property } from "@/components/Editor/Protos/Property";
import { Select } from "@/components/Editor/Protos/Select";
import { SelectStyle } from "@/components/Editor/Protos/SelectStyle";
import { SharedBetweenFlexAndGridLayout } from "@/components/Editor/Protos/SharedBetweenFlexAndGridLayout";
import { useEditorMaybe } from "@grapesjs/react";
import React, { useEffect, useState } from "react";
import { useRecoilState } from "recoil";

export const FlexLayout = () => {
  const [dir, setDir] = useState("");
  // const editor = useEditorMaybe();
  // const [currentEl , setCurrentEl] = useRecoilState(currentElState);
  // useEffect(()=>{
  //   if(!editor)return;
  //   const sle = editor.getSelected();
  //   if(!sle)return;
  //   const computedStyle = getComputedStyle()
  // },[currentEl , editor])

  useUpdateInputValue({
    cssProp:'flex-direction' ,
    setVal:(val)=>{
      console.log('val : ' , val);
      setDir(val || '')
    }
  })

  return (
    <section className="flex flex-col gap-2">
      <section className="flex flex-col gap-2">
        <FitTitle>flex direction </FitTitle>
        <MultiChoice
          choices={[
            { choice: "column", Icon: Icons.columnDir },
            { choice: "row", Icon: Icons.rowDir },
            {
              choice: `${
                dir.includes("column") ? "column-reverse" : "row-reverse"
              }`,
              Icon: Icons.reverseDir,
            },
          ]}
          setChoice={setDir}
          cssProp="flex-direction"
        />
      </section>

      <SharedBetweenFlexAndGridLayout isFlex={dir.includes('column')} dir={dir}/>

      <SelectStyle
        label="flex wrap"
        splitHyphen={false}
        cssProp="flex-wrap"
        keywords={["wrap", "nowrap", "wrap-reverse"]}
      />
      <Property label="column gap" cssProp="column-gap" />
      <Property label="row gap" cssProp="row-gap" />
      {/* <Property label="flex grow" cssProp="flex-grow" special={true} />
      <Property label="flex shrink" cssProp="flex-shrink" special={true} />
      <SelectStyle
        label="flex basis"
        cssProp="flex-basis"
        keywords={["auto", "content"]}
        splitHyphen={false}
      />
      <Property label="order" cssProp="order" special={true} /> */}

      {/* <Details label={"more options"}> */}
      {/* <section className="flex flex-col gap-3"> */}
      {/* <Select
              label="align self"
              cssProp="align-self"
              keywords={alignSelfValues}
            />
            <Select
              label="align content"
              cssProp="align-content"
              keywords={alignContentValues}
            />
            <Select
              label="align items"
              cssProp="align-items"
              keywords={alignItemsValues}
            />
  
            <Select
              label="justify self"
              cssProp="justify-self"
              keywords={justifySelfValues}
            />
            <Select
              label="justify content"
              cssProp="justify-content"
              keywords={justifyContentValues}
            />
            <Select
              label="justify items"
              cssProp="justify-items"
              keywords={justifyItemsValues}
            /> */}
    </section>
  );
};
