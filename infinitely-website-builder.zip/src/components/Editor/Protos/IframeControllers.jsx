import { wp_update_main_global_files } from "@/Apps/wordpress/functions";
import { wp_save_editor_scripts } from "@/Apps/wordpress/functions_ui";
import { animationsSavingMsg } from "@/constants/confirms";
import { InfinitelyEvents } from "@/constants/infinitelyEvents";
import {
  editorContainerInstance,
  reloadRequiredInstance,
} from "@/constants/InfinitelyInstances";
import { current_page_id, current_project_id } from "@/constants/shared";
import {
  animationsState,
  globalUndoAndRedoStates,
  isAnimationsChangedState,
  reloaderState,
  showAnimationsBuilderState,
  showComponentsInLeftPanelState,
  showLayersState,
  showsState,
  zoomValueState,
} from "@/helpers/atoms";
import { cleanMotions, filterMotionsByPage } from "@/helpers/bridge";
import {
  killAllGsapMotions,
  runAllGsapMotions,
} from "@/helpers/customEvents";
import {
  doInWordpressAsync,
  getProjectData,
  reloadInfinitely,
} from "@/helpers/functions";
import { useProjectSettings } from "@/hooks/useProjectSettings";
import { Icons } from "@/components/Icons/Icons";
import { Hr } from "@/components/Protos/Hr";
import { Li } from "@/components/Protos/Li";
import { ToastMsgInfo } from "@/components/Editor/Protos/ToastMsgInfo";
import { useEditorMaybe } from "@grapesjs/react";
import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useRecoilState, useSetRecoilState } from "recoil";

// 
// 

export const IframeControllers = () => {
  const editor = useEditorMaybe();
  const navigate = useNavigate();
  const [showLayers, setShowLayers] = useRecoilState(showLayersState);
  const [showAnimBuilder, setShowAnimBuilder] = useRecoilState(
    showAnimationsBuilderState,
  );
  const [isAnimationsChanged, setAnimationsChanged] = useRecoilState(
    isAnimationsChangedState,
  );
  const [animations, setAnimations] = useRecoilState(animationsState);
  const [zoomValue, setZoomValue] = useRecoilState(zoomValueState);
  const undoRef = useRef();
  const redoRef = useRef();
  const isEditorLoad = useRef(true);
  // const projectSettings = useRef(getProjectSettings());
  const [projectSetting, setProjectSettings] = useProjectSettings();
  const [reloader, setReloader] = useRecoilState(reloaderState);
  const [globalUndoAndRedo, setGlobalUndoAndRedo] = useRecoilState(
    globalUndoAndRedoStates,
  );
  const [shows, setShows] = useRecoilState(showsState);
  const [reloadRequired, setReloadRequired] = useState(false);
  const redoTimeoutRef = useRef();
  const undoTimeoutRef = useRef();
const [showsComponents, setShowsComponents] = useRecoilState(
    showComponentsInLeftPanelState,
  );
  useEffect(() => {
    if (!editor) return;
    editor.Keymaps.remove("core:undo");
    editor.Keymaps.remove("core:redo");

    /**
     *
     * @param {KeyboardEvent} ev
     */
    const callback = (ev) => {
      const isUndo = (ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "z";
      const isRedo = (ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "y";

      // If in an input/textarea/contenteditable, allow native undo
      const active = document.activeElement;
      const isTextInput =
        active.tagName === "INPUT" ||
        active.tagName === "TEXTAREA" ||
        active.isContentEditable;

      console.log("active : ", active);

      if (isTextInput) {
        // ✅ Allow browser native undo/redo in inputs but keep focus
        // prevent GrapesJS or other listeners from stealing it

        return;
      }

      if (isUndo || isRedo) {
        ev.preventDefault();
        ev.stopImmediatePropagation(); // stop ALL other listeners
        ev.stopPropagation();

        if (isUndo) {
          clearTimeout(undoTimeoutRef.current);
          undoTimeoutRef.current = setTimeout(() => {
            undoRef.current?.click();
          }, 0);
        }

        if (isRedo) {
          clearTimeout(redoTimeoutRef.current);
          redoTimeoutRef.current = setTimeout(() => {
            redoRef.current?.click();
          }, 0);
        }
      }
    };
    /**
     *
     * @param {CustomEvent} ev
     */
    const reloadRequiredCallback = (ev) => {
      const { state } = ev.detail;
      setReloadRequired(state);
      // doInWordpressAsync(() => {
      //   wp_save_editor_scripts()
      // });
      if (state) {
        toast.warn(<ToastMsgInfo msg={`Reload required`} />);
      }
    };

    reloadRequiredInstance.on(
      InfinitelyEvents.editor.require,
      reloadRequiredCallback,
    );
    // window.addEventListener("click", clickCallback);
    window.addEventListener("keyup", callback, true);
    // editor.on("canvas:frame:load:body", cb);
    return () => {
      // editor.off("canvas:frame:load:body", cb);
      window.removeEventListener("keyup", callback, true);
      reloadRequiredInstance.off(
        InfinitelyEvents.editor.require,
        reloadRequiredCallback,
      );
    };
  }, [editor]);

  /**
   *
   * @param {MouseEvent} ev
   */
  const undo = (ev) => {
    // editor.runCommand("core:undo");
    if (Object.values(shows).includes(true)) {
      window.undo();
      console.log("undoo ", window.undo);

      return;
    }
    editor.UndoManager.undo();
  };

  /**
   *
   * @param {MouseEvent} ev
   */
  const redo = (ev) => {
    // editor.runCommand("core:redo");
    if (Object.values(shows).includes(true)) {
      window.redo();
      console.log("redoo ", window.redo);

      return;
    }
    editor.UndoManager.redo();
  };

  const clearIFrameBody = () => {
    editor.select(null);
    editor.Components.clear();
    editor.refresh({ tools: true });
    editor.Canvas.refresh({ all: true, spots: true });
  };

  const setComponentsView = () => {
    editor.runCommand("ui:outline");
  };

  const emitZoomValue = (decrease = false) => {
    // editorObserver.unobserve(editor.getContainer());
    // console.log('editor resizer observer : ', editorObserver);
    editor.getContainer().setAttribute('zooming' , true);
    let value = editor.getContainer().style.zoom;
    value = decrease ? +value - 0.1 : +value + 0.1;
    editor.getContainer().style.zoom = value;
    editorContainerInstance.emit(InfinitelyEvents.editorContainer.update, {
      value,
    });
    // setTimeout(()=>{
    //    editorObserver.observe(editor.getContainer() , {box:'device-pixel-content-box'});
    // })
  };

  return (
    <>
      <Li
        onClick={clearIFrameBody}
        title="clear canvas"
        className="shrink-0"
        // icon={Icons.trash}
        justHover={true}
      >
        {Icons.trash(undefined, undefined, 23, 23)}
      </Li>
      <Li
        refForward={undoRef}
        className="shrink-0"
        onClick={undo}
        title="undo"
        icon={Icons.undo}
        justHover={true}
      />
      <Li
        refForward={redoRef}
        className="shrink-0"
        onClick={redo}
        title="redo"
        icon={Icons.redo}
        justHover={true}
      />

      <Li
        className="shrink-0"
        onClick={() => {
          emitZoomValue();
          // editor.Canvas.setZoom(editor.Canvas.getZoom() + 1, {
          //   avoidStore: true,
          // });
          // editor.getWrapper().getEl()
          //   .querySelectorAll("*")
          //   .forEach((el) => {
          //     const bodyScale =
          //       Number(el.style.scale) ||
          //       1;
          //     el.style.scale = bodyScale + 0.1;
          //   });
          //  editor.getWrapper().setStyle({
          //   width: `100%`,
          //   height: `100%`,
          // })
        }}
        title="zoom in"
        // isObjectParamsIcon
        // icon={Icons.zoomIn}
        justHover={false}
        fillObjectIconOnHover
        fillObjIconStroke={false}
        isObjectParamsIcon
      // hover={false}
      >
        {Icons.zoomIn({ height: `100%`, width: 22 })}
      </Li>

      <Li
        className="shrink-0"
        onClick={() => {
          emitZoomValue(true);
          // editor.Canvas.setZoom(editor.Canvas.getZoom() - 1, {
          //   avoidStore: true,
          // });

          // editor.getWrapper().getEl()
          //   .querySelectorAll("*")
          //   .forEach((el) => {
          //     const bodyScale =
          //       Number(el.style.scale) ||
          //       1;
          //     el.style.scale = bodyScale - 0.1;
          //   });
          // editor.getWrapper().setStyle({
          //   width: `100%`,
          //   height: `100%`,
          // })
        }}
        title="zoom out"
        // isObjectParamsIcon
        // icon={Icons.zoomIn}
        justHover={false}
        fillObjectIconOnHover
        fillObjIconStroke={false}
        isObjectParamsIcon
      // hover={false}
      >
        {Icons.zoomOut({ height: `100%`, width: 22 })}
      </Li>

      {/* {!projectSetting.disable_petite_vue && (
        <>
          <Li
            // refForward={redoRef}
            onClick={() => {
              unMount({
                editor,
                all: true,
              });
            }}
            title="edite components"
            fillIcon
            fillObjIcon={false}
            icon={Icons.editGjsComponent}
            isObjectParamsIcon
            className="shrink-0"
            justHover={true}
          />

          <Li
            // refForward={redoRef}
            onClick={() => {
              mount({
                editor,
                all: true,
              });
            }}
            title="mount components"
            fillIcon
            className="shrink-0"
            fillObjIcon={false}
            icon={Icons.vue}
            isObjectParamsIcon
            justHover={true}
          />
        </>
      )} */}

      <Hr />

      <Li
        // refForward={redoRef}
        onClick={async () => {
          // cleanMotions()
          // console.log("motions : ", await cleanMotions(projectData.motions, projectData.pages),);
          const projectData = await getProjectData();
          const pageName = localStorage.getItem(current_page_id);
          const motions = filterMotionsByPage(
            await cleanMotions(projectData.motions, projectData.pages, {
              [pageName]: editor.getWrapper().getInnerHTML({ withProps: true }),
            }),
            pageName,
          );
          console.log("motions : ", motions);
          // killAllGsapMotions(motions);
          runAllGsapMotions(motions);
          editor.gsapRunning = true;
        }}
        title="Run All Motions"
        fillIcon
        fillObjIcon={false}
        icon={Icons.play}
        className="shrink-0"
        isObjectParamsIcon
        justHover={true}
      />

      <Li
        // refForward={redoRef}
        onClick={async () => {
          const projectData = await getProjectData();
          const pageName = localStorage.getItem(current_page_id);
          const motions = filterMotionsByPage(
            await cleanMotions(projectData.motions, projectData.pages, {
              [pageName]: editor.getWrapper().getInnerHTML({ withProps: true }),
            }),
            pageName,
          );
          console.log("filterd motions : ", motions);

          killAllGsapMotions(motions);
          editor.gsapRunning = false;
        }}
        title="Kill All Motions"
        fillIcon
        className="shrink-0"
        fillObjIcon={false}
        icon={Icons.close}
        justHover={true}
      />

      <Li
        onClick={() => {
          editor.runCommand("toggle-preview");
          // toggleFastPreview(editor);
        }}
        className="shrink-0"
        isObjectParamsIcon
        fillObjIcon
        fillObjectIconOnHover
        justHover
        icon={Icons.binoculars}
        hover
        title="Fast Preview"
      />

      <Li
        onClick={setComponentsView}
        title="outline elements"
        className="shrink-0"
        icon={Icons.square}
        justHover={true}
      />
      <Li
        onClick={(ev) => {
          // setShowLayers((old) => !old);
          // setShowAnimBuilder(false);

          setShowsComponents(old=>({...old , layers: !old.layers , animationsBuilder: false}))
        }}
        className="shrink-0"
        icon={Icons.layers}
        title="layers"
      />
      <Li
        onClick={(ev) => {
          // console.log(showPreview, isAnimationsChanged);

          if (isAnimationsChanged && showsComponents.animationsBuilder) {
            const cnfrm = confirm(animationsSavingMsg);
            if (cnfrm) {
              setAnimationsChanged(false);
              setAnimations([]);
              // setShowAnimBuilder(false);
              setShowsComponents(old=>({...old , layers: false , animationsBuilder: false}))
            }
          } else {
            // setShowAnimBuilder(!showAnimBuilder);
            // setShowLayers(false);
            setShowsComponents(old=>({...old , layers: false , animationsBuilder: !old.animationsBuilder}))
            navigate("edite/styling");
          }
          // setShowAnimBuilder((old) => !old);
        }}
        className="shrink-0"
        title="Animation Builder"
        icon={Icons.animation}
      />
      <Li
        className="shrink-0"
        onClick={async (ev) => {
       
          // editor.off();
          // editor.load();
          // editor.destroy();
          setTimeout(() => {
            // location.replace(location.href);
            // reloadInfinitely();
            editor.load();
            setReloadRequired(false);
          }, 0);
        }}
        title="Reload Canvas"
        notify={reloadRequired}
        notifyBg="bg-[crimson]"
      >
        {Icons.refresh({
          width: 20,
          height: 20,
          strokeColor: "#64748B",
          strokWidth: 3,
        })}
      </Li>
    </>
  );
};
