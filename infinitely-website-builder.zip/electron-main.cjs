const { app, BrowserWindow, session, Menu } = require("electron");
const path = require("path");
const fs = require("fs");
// const { logMemory, forceGC } = require("./desktop/utils/memory");

require("./desktop/main-process.cjs");

async function installOPFS_Ext() {
  if (app.isPackaged) return;

  try {
    const extPath = path.join(
      process.env.LOCALAPPDATA,
      "Microsoft",
      "Edge",

      "User Data",
      "Default",
      "Extensions",
      "odbpcdmkgeikdcmcdlfmdkbjiaeknnbd",
      "0.2.0_0",
    );

    const ext = await session.defaultSession.loadExtension(extPath, {
      allowFileAccess: true,
    });

    console.log("Loaded:", ext.name);
  } catch (err) {
    console.error(err);
  }
}

async function createWindow() {
  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    show: true,
    backgroundColor: "#020617",
    icon: path.join(__dirname, "public", "favicon.ico"),
    titleBarStyle: "hidden",
    // titleBarOverlay: {
    //   color: "#0f172a", // matches your bg-slate-900
    //   symbolColor: "#ffffff",
    //   height: 39,
    // },
    webPreferences: {
      preload: path.join(__dirname, "desktop/preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('ignore-gpu-blacklist');

  if (!app.isPackaged) {
    win.webContents.on("before-input-event", (event, input) => {
      if (
        // input.type === "keyDown" &&
        input.control &&
        input.key.toLowerCase() === "r"
      ) {
        win.reload();
        event.preventDefault();
      }

      if (input.type === "keyDown" && input.key === "F12") {
        win.webContents.toggleDevTools();
        event.preventDefault();
      }

      if (
        input.type === "keyDown" &&
        input.control &&
        input.shift &&
        input.key.toLowerCase() === "i"
      ) {
        win.webContents.toggleDevTools();
        event.preventDefault();
      }
    });
  }

  // logMemory("Before");

  // setTimeout(() => {
  //   logMemory("Before GC");

  //   forceGC();

  //   setTimeout(() => {
  //     logMemory("After GC");
  //   }, 500);
  // }, 2000);

  await win.loadFile(path.join(__dirname, "desktop/splash.html"));

  await new Promise((resolve) => setTimeout(resolve, 1000));

  if (!app.isPackaged) {
    await win.loadURL("https://localhost:5173/add-blocks");
  } else {
    // await win.loadFile(path.join(__dirname, "dist", "index.html"));
    await win.loadURL("https://infinitely.pages.dev/add-blocks");
  }
}

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  await installOPFS_Ext();
  await createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
